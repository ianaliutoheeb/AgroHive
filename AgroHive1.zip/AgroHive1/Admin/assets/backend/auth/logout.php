<?php
    require('../../../../utility/utility.php');
    unset($_SESSION['IS_LOGIN_ADMIN']);
    unset($_SESSION['PVL_ADMIN']);
    unset($_SESSION['ADMIN_ID']);
    echo 1;
    die();
?>